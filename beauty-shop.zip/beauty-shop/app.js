// Config
const PAGE_SIZE = 30;

// Seed data (sample salon/beauty equipment)
const baseProducts = [
  {id:1, title:"صندلی آرایشگاهی کلاسیک", category:"صندلی", price: 7800000, rating:4.7, emoji:"🪑", createdAt: "2025-05-01"},
  {id:2, title:"صندلی هیدرولیک حرفه‌ای", category:"صندلی", price: 12500000, rating:4.9, emoji:"🛠️", createdAt: "2025-06-10"},
  {id:3, title:"آینه قدی لبه‌نور", category:"آینه", price: 5600000, rating:4.6, emoji:"🪞", createdAt: "2025-02-18"},
  {id:4, title:"سشوار سالنی دیواری", category:"برقی", price: 4300000, rating:4.4, emoji:"💨", createdAt: "2025-03-05"},
  {id:5, title:"ترولی سه طبقه استیل", category:"ترولی", price: 3200000, rating:4.3, emoji:"🧰", createdAt: "2025-01-22"},
  {id:6, title:"پایه سشوار چرخ‌دار", category:"لوازم جانبی", price: 1100000, rating:4.2, emoji:"🛒", createdAt: "2025-04-11"},
  {id:7, title:"روشویی سالنی سرامیکی", category:"روشویی", price: 9800000, rating:4.5, emoji:"🚿", createdAt: "2025-05-28"},
  {id:8, title:"کاسه رنگ مو و برس", category:"مصرفی", price: 180000, rating:4.1, emoji:"🧪", createdAt: "2025-07-02"},
  {id:9, title:"مخزن ضدعفونی UV", category:"بهداشت", price: 2100000, rating:4.6, emoji:"🔆", createdAt: "2025-03-29"},
  {id:10, title:"پیشبند آرایشگاهی ضدآب", category:"مصرفی", price: 240000, rating:4.0, emoji:"🧥", createdAt: "2025-04-01"},
];
// Duplicate to simulate >30 items
let nextId = 11;
const cats = ["صندلی","آینه","برقی","ترولی","روشویی","مصرفی","بهداشت","لوازم جانبی"];
for (let i=0;i<50;i++){
  const c = cats[i % cats.length];
  baseProducts.push({
    id: nextId++,
    title: `${c} مدل ${100+i}`,
    category: c,
    price: Math.floor(200000 + Math.random()*15000000),
    rating: (Math.random()*1.5+3.5).toFixed(1),
    emoji: ["🪑","🪞","💨","🧰","🚿","🧪","🔆","🛒"][i%8],
    createdAt: new Date(2025, Math.floor(Math.random()*7), Math.floor(Math.random()*28)+1).toISOString().slice(0,10)
  })
}

// Merge custom products from admin (localStorage)
function loadCustomProducts(){
  try{
    const raw = localStorage.getItem("customProducts");
    if(!raw) return [];
    const arr = JSON.parse(raw);
    return Array.isArray(arr)? arr: [];
  }catch(e){return []}
}
let products = [...baseProducts, ...loadCustomProducts()];

// State
let state = {
  q: "",
  category: "all",
  sort: "popular",
  page: 1,
  cart: loadCart()
};

function formatPrice(n){
  return n.toLocaleString("fa-IR");
}

function saveCart(cart){
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
}
function loadCart(){
  try{
    const x = JSON.parse(localStorage.getItem("cart")||"[]");
    return Array.isArray(x)? x: [];
  }catch(e){return []}
}
function updateCartCount(){
  const count = state.cart.reduce((a,i)=>a+i.qty,0);
  document.getElementById("cartCount").textContent = count;
}

// UI bindings
const menuBtn = document.getElementById("menuBtn");
const topNav = document.getElementById("topNav");
menuBtn?.addEventListener("click",()=>{
  const open = topNav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open ? "true":"false");
});

document.getElementById("searchInput").addEventListener("input", (e)=>{
  state.q = e.target.value.trim();
  state.page = 1;
  render();
});

const categorySelect = document.getElementById("categorySelect");
const sortSelect = document.getElementById("sortSelect");

function initFilters(){
  const set = new Set(products.map(p=>p.category));
  for (const c of Array.from(set)){
    const opt = document.createElement("option");
    opt.value = c;
    opt.textContent = c;
    categorySelect.appendChild(opt);
  }
  categorySelect.addEventListener("change", e=>{
    state.category = e.target.value;
    state.page = 1;
    render();
  });
  sortSelect.addEventListener("change", e=>{
    state.sort = e.target.value;
    state.page = 1;
    render();
  });
}

function filterAndSort(){
  let list = products.filter(p=>{
    const okCat = state.category==="all" || p.category===state.category;
    const okQ = !state.q || p.title.includes(state.q);
    return okCat && okQ;
  });
  switch(state.sort){
    case "price-asc": list.sort((a,b)=>a.price-b.price); break;
    case "price-desc": list.sort((a,b)=>b.price-a.price); break;
    case "newest": list.sort((a,b)=> new Date(b.createdAt)-new Date(a.createdAt)); break;
    default: list.sort((a,b)=>b.rating-a.rating);
  }
  return list;
}

function renderProducts(list){
  const grid = document.getElementById("products");
  grid.innerHTML = "";
  for (const p of list){
    const card = document.createElement("article");
    card.className = "card product";
    card.innerHTML = `
      <div class="img" aria-label="${p.title}">${p.emoji||"🛍️"}</div>
      <div class="title">${p.title}</div>
      <div class="meta">دسته: ${p.category} • امتیاز: ${p.rating}</div>
      <div class="price">${formatPrice(p.price)} <span class="meta">تومان</span></div>
      <button class="btn primary" data-id="${p.id}">افزودن به سبد</button>
    `;
    card.querySelector("button").addEventListener("click",()=>addToCart(p.id));
    grid.appendChild(card);
  }
}

function renderPagination(total){
  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  const pag = document.getElementById("pagination");
  pag.innerHTML = "";
  function addBtn(label, page, disabled=false, active=false){
    const b = document.createElement("button");
    b.textContent = label;
    b.className = "page-btn" + (active? " active":"");
    b.disabled = disabled;
    b.addEventListener("click", ()=>{ state.page = page; render(); });
    pag.appendChild(b);
  }
  addBtn("قبلی", Math.max(1, state.page-1), state.page===1);
  // Pages (compress if many)
  const totalPagesToShow = Math.min(7, totalPages);
  const start = Math.max(1, Math.min(state.page-3, totalPages-totalPagesToShow+1));
  const end = Math.min(totalPages, start + totalPagesToShow - 1);
  for(let i=start;i<=end;i++){
    addBtn(i, i, false, i===state.page);
  }
  addBtn("بعدی", Math.min(totalPages, state.page+1), state.page===totalPages);
}

function addToCart(id){
  const p = products.find(x=>x.id===id);
  const existing = state.cart.find(x=>x.id===id);
  if(existing){ existing.qty += 1; }
  else{ state.cart.push({id:p.id, title:p.title, price:p.price, emoji:p.emoji, qty:1}); }
  saveCart(state.cart);
  openCart();
  renderCart();
}

const cartDrawer = document.getElementById("cartDrawer");
document.getElementById("cartBtn").addEventListener("click", ()=> openCart());
document.getElementById("closeCart").addEventListener("click", ()=> closeCart());
function openCart(){ cartDrawer.classList.add("open"); cartDrawer.setAttribute("aria-hidden","false"); }
function closeCart(){ cartDrawer.classList.remove("open"); cartDrawer.setAttribute("aria-hidden","true"); }

function renderCart(){
  const list = document.getElementById("cartItems");
  list.innerHTML = "";
  let total = 0;
  for(const item of state.cart){
    total += item.price * item.qty;
    const row = document.createElement("div");
    row.className = "cart-item";
    row.innerHTML = `
      <div class="thumb">${item.emoji||"🛍️"}</div>
      <div>
        <div><strong>${item.title}</strong></div>
        <div class="meta">${formatPrice(item.price)} تومان</div>
        <div class="meta">تعداد: 
          <button class="icon-btn dec">-</button>
          <span class="qty">${item.qty}</span>
          <button class="icon-btn inc">+</button>
          <button class="icon-btn remove">حذف</button>
        </div>
      </div>
      <div><strong>${formatPrice(item.price*item.qty)}</strong></div>
    `;
    row.querySelector(".dec").addEventListener("click", ()=>{ item.qty=Math.max(1,item.qty-1); saveCart(state.cart); renderCart(); });
    row.querySelector(".inc").addEventListener("click", ()=>{ item.qty+=1; saveCart(state.cart); renderCart(); });
    row.querySelector(".remove").addEventListener("click", ()=>{ state.cart=state.cart.filter(x=>x.id!==item.id); saveCart(state.cart); renderCart(); });
    list.appendChild(row);
  }
  document.getElementById("cartTotal").textContent = formatPrice(total);
}

document.getElementById("checkoutBtn").addEventListener("click", ()=>{
  alert("این یک دموی استاتیک است. برای اتصال درگاه پرداخت، باید بک‌اند یا سرویس واسط پرداخت داشته باشید.");
});

function render(){
  const list = filterAndSort();
  const start = (state.page-1)*PAGE_SIZE;
  const pageItems = list.slice(start, start+PAGE_SIZE);
  renderProducts(pageItems);
  renderPagination(list.length);
  renderCart();
}

document.getElementById("year").textContent = new Date().getFullYear();
initFilters();
updateCartCount();
render();

// Listen to customProducts changes (admin page may update localStorage)
window.addEventListener("storage", (e)=>{
  if(e.key==="customProducts"){
    const custom = loadCustomProducts();
    products = [...baseProducts, ...custom];
    initCategoryOnce = false;
    document.getElementById("categorySelect").innerHTML = "<option value='all'>همه</option>";
    initFilters();
    render();
  }
});
